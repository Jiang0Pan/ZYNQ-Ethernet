/*
  ** @file           : pca9535bs.h
  ** @brief          : The Device Of PCA9535BS(IIC Extension I/O Device) Header File
  **
  ** @attention
  **
  ** Copyright (c) 2020 ChengDuHangke.
  ** All rights reserved.
  **
  ** This software is licensed by ChengDuHangke under Ultimate Liberty license
  **
*/


#ifndef SRC_INCLUDE_PCA9535_H_
#define SRC_INCLUDE_PCA9535_H_


/*
  ** Include
*/


/*
  ** Define
*/


#endif /* SRC_INCLUDE_PCA9535_H_ */


/*
  ** (C) COPYRIGHT ChengDuHangke END OF FILE
*/
