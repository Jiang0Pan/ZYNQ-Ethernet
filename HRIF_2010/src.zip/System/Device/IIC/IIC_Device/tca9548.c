/*
  ** @file           : tca9548arger.c
  ** @brief          : The Device Of TCA9548ARGER(IIC Extension IIC Device) Source File
  **
  ** @attention
  **
  ** Copyright (c) 2020 ChengDuHangke.
  ** All rights reserved.
  **
  ** This software is licensed by ChengDuHangke under Ultimate Liberty license
  **
*/


/*
  ** Include
*/
#include "tca9548.h"


/*
  ** (C) COPYRIGHT ChengDuHangke END OF FILE
*/
